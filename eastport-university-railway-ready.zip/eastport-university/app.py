import hashlib
import hmac
import os
import re
import secrets
import smtplib
import sqlite3
import time
import uuid
from datetime import date, datetime, timedelta
from email.message import EmailMessage
from functools import wraps
from pathlib import Path
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo

from flask import (Flask, abort, flash, g, redirect, render_template, request,
                   send_from_directory, session, url_for)
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import check_password_hash, generate_password_hash

BASE = Path(__file__).resolve().parent
APP_ENV = os.environ.get("APP_ENV", "development").strip().lower()
IS_PRODUCTION = APP_ENV in {"production", "prod"}
DB_PATH = Path(os.environ.get("DATABASE_PATH", str(BASE / "instance" / "university.db"))).expanduser().resolve()
UPLOAD_DIR = Path(os.environ.get("UPLOAD_DIR", str(BASE / "uploads"))).expanduser().resolve()
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

CAIRO = ZoneInfo("Africa/Cairo")
ALLOWED_EXT = {"pdf": "pdf", "mp4": "video", "webm": "video", "mov": "video"}
ROLES = ("admin", "doctor", "student")
YEARS = (1, 2, 3, 4)
TERMS = (1, 2)
COURSES_PER_TERM = 7
MAX_EXAM_MINUTES = 300
EXAM_GRACE_SECONDS = 30   # tolerance for network delay at the deadline
VERIFY_HOURS = 24
MIN_PASSWORD_LENGTH = 12
LOGIN_MAX_FAILURES = 8
LOGIN_WINDOW_SECONDS = 15 * 60
LOGIN_LOCK_SECONDS = 15 * 60
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

# Egyptian governorate codes (digits 8-9 of the national ID)
GOVERNORATES = {1, 2, 3, 4, 11, 12, 13, 14, 15, 16, 17, 18, 19, 21, 22, 23, 24, 25,
                26, 27, 28, 29, 31, 32, 33, 34, 35, 88}

DEPARTMENTS = [
    ("SHP", "قسم تشغيل وصيانة السفن", "Ship Operation & Maintenance"),
    ("FUR", "قسم الأثاث", "Furniture Department"),
    ("FOD", "قسم الأغذية", "Food Department"),
]

T = {
    "site": ("المنصة التعليمية - جامعة شرق بورسعيد التكنولوجية", "E-Learning - Port Said East Technological University"),
    "faculty": ("كلية الصناعة والطاقة", "Faculty of Industry and Energy"),
    "departments": ("الأقسام", "Departments"),
    "users": ("المستخدمون", "Users"),
    "logout": ("خروج", "Logout"),
    "login": ("تسجيل الدخول", "Login"),
    "username": ("اسم المستخدم", "Username"),
    "password": ("كلمة المرور", "Password"),
    "invalid_login": ("اسم المستخدم أو كلمة المرور غير صحيحة", "Invalid username or password"),
    "role_admin": ("إدارة", "Admin"),
    "role_doctor": ("دكتور", "Doctor"),
    "role_student": ("طالب", "Student"),
    "year": ("السنة", "Year"),
    "term": ("الترم", "Term"),
    "code": ("الكود", "Code"),
    "name": ("اسم المادة", "Course name"),
    "materials": ("المحاضرات والملفات", "Lectures & files"),
    "exams": ("الامتحانات", "Exams"),
    "upload": ("رفع", "Upload"),
    "title": ("العنوان", "Title"),
    "link": ("أو رابط خارجي", "or external link"),
    "add": ("إضافة", "Add"),
    "delete": ("حذف", "Delete"),
    "edit": ("تعديل", "Edit"),
    "name_ar": ("الاسم بالعربي", "Arabic name"),
    "name_en": ("الاسم بالإنجليزي", "English name"),
    "doctor": ("الدكتور المسؤول", "Responsible doctor"),
    "none": ("— بدون —", "— none —"),
    "save": ("حفظ", "Save"),
    "no_materials": ("لا توجد محاضرات بعد", "No materials yet"),
    "no_exams": ("لا توجد امتحانات بعد", "No exams yet"),
    "new_exam": ("امتحان جديد", "New exam"),
    "add_question": ("إضافة سؤال", "Add question"),
    "question": ("نص السؤال", "Question"),
    "questions": ("الأسئلة", "Questions"),
    "option": ("الخيار", "Option"),
    "correct_option": ("رقم الإجابة الصحيحة", "Correct option number"),
    "take_exam": ("ابدأ الامتحان", "Start exam"),
    "submit": ("تسليم الإجابات", "Submit answers"),
    "score": ("الدرجة", "Score"),
    "result": ("النتيجة", "Result"),
    "of": ("من", "of"),
    "already_taken": ("لقد أديت هذا الامتحان بالفعل", "You have already taken this exam"),
    "no_questions": ("لا توجد أسئلة بعد", "No questions yet"),
    "attempts": ("طالب أدى الامتحان", "students took it"),
    "saved": ("تم الحفظ", "Saved"),
    "deleted": ("تم الحذف", "Deleted"),
    "created": ("تم الإنشاء", "Created"),
    "forbidden": ("ليس لديك صلاحية لعرض هذه الصفحة", "You do not have access to this page"),
    "not_found": ("الصفحة غير موجودة", "Page not found"),
    "full_name": ("الاسم الكامل", "Full name"),
    "department": ("القسم", "Department"),
    "create_user": ("إنشاء مستخدم", "Create user"),
    "back": ("رجوع", "Back"),
    "home": ("الرئيسية", "Home"),
    "required": ("يرجى تعبئة كل الحقول المطلوبة", "Please fill in all required fields"),
    "bad_file": ("نوع الملف غير مدعوم (PDF أو MP4 أو WEBM أو MOV فقط)", "Unsupported file type (PDF, MP4, WEBM or MOV only)"),
    "bad_url": ("الرابط يجب أن يبدأ بـ http:// أو https://", "Link must start with http:// or https://"),
    "username_taken": ("اسم المستخدم موجود بالفعل", "Username already exists"),
    "short_password": ("كلمة المرور يجب ألا تقل عن 12 حرفًا", "Password must be at least 12 characters"),
    "long_password": ("كلمة المرور طويلة جدًا (الحد الأقصى 256 حرفًا)", "Password is too long (maximum 256 characters)"),
    "exam_locked": ("لا يمكن تعديل أسئلة الامتحان بعد بدء أي طالب فيه", "Questions cannot be changed after a student has started the exam"),
    "cannot_delete_self": ("لا يمكنك حذف حسابك الخاص", "You cannot delete your own account"),
    "error": ("حدث خطأ", "Something went wrong"),
    "register": ("إنشاء حساب طالب", "Create student account"),
    "have_account": ("عندي حساب بالفعل", "I already have an account"),
    "no_account": ("ليس لديك حساب؟ سجّل كطالب", "No account? Register as a student"),
    "confirm_password": ("تأكيد كلمة المرور", "Confirm password"),
    "password_mismatch": ("كلمتا المرور غير متطابقتين", "Passwords do not match"),
    "duration_min": ("المدة بالدقائق", "Duration (minutes)"),
    "invalid_duration": ("المدة يجب أن تكون بين 1 و 300 دقيقة", "Duration must be between 1 and 300 minutes"),
    "time_left": ("الوقت المتبقي", "Time left"),
    "time_up": ("انتهى الوقت، تم تسليم الامتحان تلقائياً", "Time is up; the exam was submitted automatically"),
    "start_first": ("ابدأ الامتحان من صفحته أولاً", "Start the exam from its page first"),
    "minutes": ("دقيقة", "minutes"),
    "email": ("البريد الإلكتروني", "Email"),
    "email_invalid": ("البريد الإلكتروني غير صحيح", "Invalid email address"),
    "email_taken": ("هذا البريد مسجل بالفعل", "This email is already registered"),
    "national_id": ("الرقم القومي (14 رقم)", "National ID (14 digits)"),
    "nid_invalid": ("الرقم القومي غير صحيح", "Invalid national ID"),
    "nid_taken": ("هذا الرقم القومي مسجل بالفعل", "This national ID is already registered"),
    "verify_sent": ("تم إنشاء الحساب. أرسلنا رابط التفعيل إلى بريدك، فعّل الحساب ثم سجّل الدخول", "Account created. We sent an activation link to your email; activate it, then log in"),
    "verify_needed": ("حسابك غير مفعّل. أرسلنا رابط تفعيل جديد إلى بريدك", "Your account is not activated. We sent a new activation link to your email"),
    "verify_done": ("تم تفعيل حسابك، يمكنك تسجيل الدخول الآن", "Your account is activated; you can log in now"),
    "verify_confirm": ("تأكيد تفعيل الحساب", "Confirm account activation"),
    "verify_invalid": ("رابط التفعيل غير صالح أو انتهت صلاحيته", "The activation link is invalid or has expired"),
    "mail_failed": ("تعذر إرسال البريد الإلكتروني، حاول لاحقاً أو اطلب من الإدارة", "Could not send the email; try again later or ask the administration"),
    "verified": ("مفعّل", "Activated"),
    "not_verified": ("غير مفعّل", "Not activated"),
    "window": ("نافذة الامتحان", "Exam window"),
    "opens_label": ("وقت الفتح (اختياري)", "Opens at (optional)"),
    "closes_label": ("وقت الإغلاق (اختياري)", "Closes at (optional)"),
    "opens_at": ("يفتح", "Opens"),
    "closes_at": ("يغلق", "Closes"),
    "always_open": ("متاح دائماً", "Always available"),
    "invalid_window": ("أوقات الامتحان غير صحيحة، وقت الإغلاق يجب أن يكون بعد وقت الفتح", "Invalid exam window: closing time must be after opening time"),
    "window_upcoming": ("الامتحان لم يبدأ بعد", "The exam has not started yet"),
    "window_closed": ("الامتحان مغلق", "The exam is closed"),
    "status_upcoming": ("لم يبدأ بعد", "Not started yet"),
    "status_closed": ("مغلق", "Closed"),
    "status_open": ("متاح الآن", "Open now"),
    "nid_last4": ("آخر 4 أرقام", "Last 4 digits"),
}

secret_key = os.environ.get("SECRET_KEY")
trusted_hosts = [host.strip() for host in os.environ.get("TRUSTED_HOSTS", "").split(",") if host.strip()]
public_base_url = os.environ.get("PUBLIC_BASE_URL", "").strip().rstrip("/")

if IS_PRODUCTION:
    missing = [name for name, value in {
        "SECRET_KEY": secret_key,
        "TRUSTED_HOSTS": trusted_hosts,
        "PUBLIC_BASE_URL": public_base_url,
        "SMTP_HOST": os.environ.get("SMTP_HOST"),
        "SMTP_FROM": os.environ.get("SMTP_FROM"),
    }.items() if not value]
    if missing:
        raise RuntimeError("Missing production environment variables: " + ", ".join(missing))
    if len(secret_key) < 32:
        raise RuntimeError("SECRET_KEY must contain at least 32 characters in production")
    if not public_base_url.startswith("https://"):
        raise RuntimeError("PUBLIC_BASE_URL must use https:// in production")

app = Flask(__name__)
app.config.update(
    SECRET_KEY=secret_key or secrets.token_hex(32),
    MAX_CONTENT_LENGTH=int(os.environ.get("MAX_CONTENT_LENGTH", str(500 * 1024 * 1024))),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=IS_PRODUCTION,
    PERMANENT_SESSION_LIFETIME=timedelta(hours=12),
    TRUSTED_HOSTS=trusted_hosts or None,
    PUBLIC_BASE_URL=public_base_url,
)

# Enable only when the app is bound to a trusted reverse proxy (for example Nginx on localhost).
if os.environ.get("BEHIND_PROXY", "false").lower() == "true":
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)


@app.after_request
def add_security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    if IS_PRODUCTION or request.is_secure:
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000")
    if response.mimetype == "text/html":
        response.headers.setdefault("Cache-Control", "no-store")
    return response


# ---------- Database ----------

SCHEMA = """
CREATE TABLE IF NOT EXISTS departments (
    id INTEGER PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    name_ar TEXT NOT NULL,
    name_en TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'doctor', 'student')),
    dept_id INTEGER REFERENCES departments(id),
    year INTEGER,
    email TEXT UNIQUE,
    email_verified INTEGER NOT NULL DEFAULT 0,
    national_id_hash TEXT UNIQUE,
    national_id_last4 TEXT
);
CREATE TABLE IF NOT EXISTS email_tokens (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS courses (
    id INTEGER PRIMARY KEY,
    dept_id INTEGER NOT NULL REFERENCES departments(id),
    year INTEGER NOT NULL,
    term INTEGER NOT NULL,
    position INTEGER NOT NULL,
    code TEXT NOT NULL,
    name_ar TEXT NOT NULL,
    name_en TEXT NOT NULL,
    doctor_id INTEGER REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS materials (
    id INTEGER PRIMARY KEY,
    course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    kind TEXT NOT NULL,
    stored_name TEXT,
    url TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS exams (
    id INTEGER PRIMARY KEY,
    course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    duration_minutes INTEGER NOT NULL DEFAULT 30 CHECK (duration_minutes BETWEEN 1 AND 300),
    opens_at REAL,
    closes_at REAL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS exam_starts (
    exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
    student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    started_at REAL NOT NULL,
    PRIMARY KEY (exam_id, student_id)
);
CREATE TABLE IF NOT EXISTS questions (
    id INTEGER PRIMARY KEY,
    exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    opt1 TEXT NOT NULL, opt2 TEXT NOT NULL, opt3 TEXT NOT NULL, opt4 TEXT NOT NULL,
    correct INTEGER NOT NULL CHECK (correct BETWEEN 1 AND 4)
);
CREATE TABLE IF NOT EXISTS attempts (
    id INTEGER PRIMARY KEY,
    exam_id INTEGER NOT NULL REFERENCES exams(id) ON DELETE CASCADE,
    student_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    score INTEGER NOT NULL,
    total INTEGER NOT NULL,
    taken_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (exam_id, student_id)
);
CREATE TABLE IF NOT EXISTS login_throttles (
    throttle_key TEXT PRIMARY KEY,
    window_started REAL NOT NULL,
    failures INTEGER NOT NULL DEFAULT 0,
    blocked_until REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_courses_dept_year ON courses(dept_id, year, term, position);
CREATE INDEX IF NOT EXISTS idx_materials_course ON materials(course_id);
CREATE INDEX IF NOT EXISTS idx_exams_course ON exams(course_id);
CREATE INDEX IF NOT EXISTS idx_questions_exam ON questions(exam_id);
CREATE INDEX IF NOT EXISTS idx_attempts_exam ON attempts(exam_id);
CREATE INDEX IF NOT EXISTS idx_email_tokens_user ON email_tokens(user_id);
"""


def connect():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 30000")
    # Keep SQLite's rollback journal and FULL durability by default.
    # Do not enable WAL without confirming the linked SQLite library includes current WAL fixes.
    conn.execute("PRAGMA synchronous = FULL")
    return conn


def db():
    if "db" not in g:
        g.db = connect()
    return g.db


def execute(sql, params=()):
    cur = db().execute(sql, params)
    db().commit()
    return cur


@app.teardown_appcontext
def close_db(_exc):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db():
    """Create/update schema and seed missing catalogue rows. Run explicitly via `flask init-db`."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = connect()
    try:
        # Explicitly retain rollback-journal mode for compatibility with system SQLite builds.
        conn.execute("PRAGMA journal_mode = DELETE")
        conn.executescript(SCHEMA)

        for code, name_ar, name_en in DEPARTMENTS:
            conn.execute(
                "INSERT OR IGNORE INTO departments (code, name_ar, name_en) VALUES (?, ?, ?)",
                (code, name_ar, name_en),
            )

        for dept in conn.execute("SELECT id, code FROM departments").fetchall():
            for year in YEARS:
                for term in TERMS:
                    for pos in range(1, COURSES_PER_TERM + 1):
                        exists = conn.execute(
                            "SELECT 1 FROM courses WHERE dept_id = ? AND year = ? AND term = ? AND position = ? LIMIT 1",
                            (dept["id"], year, term, pos),
                        ).fetchone()
                        if not exists:
                            conn.execute(
                                "INSERT INTO courses (dept_id, year, term, position, code, name_ar, name_en) "
                                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                                (dept["id"], year, term, pos, f"{dept['code']}{year}{term}{pos}",
                                 f"مادة {year}-{term}-{pos}", f"Course {year}-{term}-{pos}"),
                            )

        admin_exists = conn.execute("SELECT 1 FROM users WHERE role = 'admin' LIMIT 1").fetchone()
        if not admin_exists:
            password = os.environ.get("ADMIN_PASSWORD")
            if not password:
                if IS_PRODUCTION:
                    raise RuntimeError("Set ADMIN_PASSWORD before running `flask init-db` in production")
                password = secrets.token_urlsafe(24)
                print("[init] No ADMIN_PASSWORD supplied; generated a one-time admin password below.", flush=True)
                print(f"[init] username: admin | password: {password}", flush=True)
            if len(password) < MIN_PASSWORD_LENGTH:
                raise RuntimeError(f"ADMIN_PASSWORD must be at least {MIN_PASSWORD_LENGTH} characters")
            if conn.execute("SELECT 1 FROM users WHERE username = 'admin'").fetchone():
                raise RuntimeError("Username 'admin' already exists but is not an admin; rename it before bootstrap")
            conn.execute(
                "INSERT INTO users (username, password_hash, full_name, role, email_verified) "
                "VALUES (?, ?, ?, 'admin', 1)",
                ("admin", generate_password_hash(password), "Administrator"),
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


@app.cli.command("init-db")
def init_db_command():
    """Initialize the schema and create any missing default catalogue records."""
    init_db()
    print(f"Database initialized at: {DB_PATH}")


# ---------- Helpers ----------

def tt(key):
    ar, en = T.get(key, (key, key))
    return ar if session.get("lang", "ar") == "ar" else en


def _now():
    return time.time()


def current_user():
    if not hasattr(g, "user"):
        uid = session.get("uid")
        g.user = db().execute(
            "SELECT id, username, full_name, role, dept_id, year, email_verified "
            "FROM users WHERE id = ?", (uid,)
        ).fetchone() if uid else None
    return g.user


def csrf_token():
    if not session.get("csrf"):
        session["csrf"] = secrets.token_hex(16)
    return session["csrf"]


@app.before_request
def verify_csrf():
    if request.method == "POST":
        sent = request.form.get("csrf", "")
        if not session.get("csrf") or not secrets.compare_digest(sent, session["csrf"]):
            abort(400)


@app.context_processor
def inject_globals():
    lg = session.get("lang", "ar")
    return {
        "lang": lg,
        "dir": "rtl" if lg == "ar" else "ltr",
        "tr": tt,
        "nm": lambda row, field: row[f"{field}_{lg}"],
        "user": current_user(),
        "csrf": csrf_token(),
    }


@app.template_filter("cairo")
def cairo_filter(ts):
    return datetime.fromtimestamp(ts, CAIRO).strftime("%Y-%m-%d %H:%M") if ts else "—"


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            return redirect(url_for("login", next=request.full_path))
        return fn(*args, **kwargs)
    return wrapper


def role_required(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user = current_user()
            if user is None:
                return redirect(url_for("login"))
            if user["role"] not in roles:
                abort(403)
            return fn(*args, **kwargs)
        return wrapper
    return decorator


def can_view(row):
    """row must include dept_id, year."""
    u = current_user()
    if u["role"] in ("admin", "doctor"):
        return True
    return u["dept_id"] == row["dept_id"] and u["year"] == row["year"]


def can_manage(row):
    """row must include doctor_id."""
    u = current_user()
    return u["role"] == "admin" or (u["role"] == "doctor" and row["doctor_id"] == u["id"])


def get_department(dept_id):
    row = db().execute("SELECT * FROM departments WHERE id = ?", (dept_id,)).fetchone()
    if row is None:
        abort(404)
    return row


COURSE_SQL = """
SELECT c.*, d.name_ar AS dept_name_ar, d.name_en AS dept_name_en, u.full_name AS doctor_name
FROM courses c
JOIN departments d ON d.id = c.dept_id
LEFT JOIN users u ON u.id = c.doctor_id
"""


def get_course(cid):
    row = db().execute(COURSE_SQL + " WHERE c.id = ?", (cid,)).fetchone()
    if row is None:
        abort(404)
    return row


def get_exam(eid):
    row = db().execute(
        "SELECT e.*, c.id AS course_id, c.dept_id, c.year, c.doctor_id, "
        "c.name_ar AS course_name_ar, c.name_en AS course_name_en "
        "FROM exams e JOIN courses c ON c.id = e.course_id WHERE e.id = ?", (eid,)
    ).fetchone()
    if row is None:
        abort(404)
    return row


def get_material(mid):
    row = db().execute(
        "SELECT m.*, c.dept_id, c.year, c.doctor_id FROM materials m "
        "JOIN courses c ON c.id = m.course_id WHERE m.id = ?", (mid,)
    ).fetchone()
    if row is None:
        abort(404)
    return row


def safe_next(target):
    if not target or not target.startswith("/") or target.startswith("//") or "\\" in target:
        return url_for("departments")
    parsed = urlsplit(target)
    if parsed.scheme or parsed.netloc:
        return url_for("departments")
    return target


def exam_status(e, now):
    """Return 'upcoming', 'open' or 'closed' based on the exam's time window."""
    if e["opens_at"] and now < e["opens_at"]:
        return "upcoming"
    if e["closes_at"] and now >= e["closes_at"]:
        return "closed"
    return "open"


def parse_local_datetime(value):
    """Parse a datetime-local value entered as Cairo time. Returns (valid, timestamp or None)."""
    value = value.strip()
    if not value:
        return True, None
    try:
        return True, datetime.strptime(value, "%Y-%m-%dT%H:%M").replace(tzinfo=CAIRO).timestamp()
    except ValueError:
        return False, None


# ---------- Identity checks, email verification ----------

def hash_token(token):
    return hashlib.sha256(token.encode()).hexdigest()


def national_id_hash(nid):
    # Keyed hash so the stored value cannot be reversed or matched without SECRET_KEY.
    return hmac.new(app.config["SECRET_KEY"].encode(), nid.encode(), hashlib.sha256).hexdigest()


def check_national_id(nid):
    """Format check for an Egyptian national ID. Returns an error key, or None if valid."""
    if not (len(nid) == 14 and nid.isascii() and nid.isdigit()):
        return "nid_invalid"
    century = {"2": 1900, "3": 2000}.get(nid[0])
    if century is None:
        return "nid_invalid"
    try:
        birth = date(century + int(nid[1:3]), int(nid[3:5]), int(nid[5:7]))
    except ValueError:
        return "nid_invalid"
    if birth > datetime.now(CAIRO).date() or int(nid[7:9]) not in GOVERNORATES:
        return "nid_invalid"
    return None


def send_mail(to, subject, body):
    host = os.environ.get("SMTP_HOST")
    if not host:
        if IS_PRODUCTION:
            app.logger.error("SMTP_HOST is missing; activation email was not sent")
            return False
        # Development-only fallback. Never print activation tokens to production logs.
        print(f"[mail] to={to} subject={subject}\n{body}\n", flush=True)
        return True
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = os.environ.get("SMTP_FROM", "no-reply@localhost")
    msg["To"] = to
    msg.set_content(body)
    try:
        port = int(os.environ.get("SMTP_PORT", "587"))
        if os.environ.get("SMTP_USE_SSL", "false").lower() == "true":
            smtp_context = smtplib.SMTP_SSL(host, port, timeout=15)
        else:
            smtp_context = smtplib.SMTP(host, port, timeout=15)
        with smtp_context as smtp:
            smtp.ehlo()
            if not isinstance(smtp, smtplib.SMTP_SSL):
                smtp.starttls()
                smtp.ehlo()
            if os.environ.get("SMTP_USER"):
                smtp.login(os.environ["SMTP_USER"], os.environ.get("SMTP_PASSWORD", ""))
            smtp.send_message(msg)
        return True
    except (OSError, smtplib.SMTPException, ValueError):
        app.logger.exception("Failed to send an email message")
        return False


def send_verification(user_id, email, full_name):
    token = secrets.token_urlsafe(32)
    execute("DELETE FROM email_tokens WHERE user_id = ?", (user_id,))
    execute("INSERT INTO email_tokens (token_hash, user_id, expires_at) VALUES (?, ?, ?)",
            (hash_token(token), user_id, _now() + VERIFY_HOURS * 3600))
    relative_link = url_for("verify_email", token=token)
    link = (app.config["PUBLIC_BASE_URL"] + relative_link
            if app.config["PUBLIC_BASE_URL"] else url_for("verify_email", token=token, _external=True))
    body = (f"مرحباً {full_name}،\n\nلتفعيل حسابك في المنصة التعليمية اضغط على الرابط التالي:\n{link}\n\n"
            f"الرابط صالح لمدة {VERIFY_HOURS} ساعة.\n\n"
            f"Hello {full_name}, activate your account using this link:\n{link}\n"
            f"The link is valid for {VERIFY_HOURS} hours.")
    return send_mail(email, "تفعيل حسابك / Activate your account", body)


def insert_user(data):
    return execute(
        "INSERT INTO users (username, password_hash, full_name, role, dept_id, year, email, "
        "email_verified, national_id_hash, national_id_last4) VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?)",
        (data["username"], generate_password_hash(data["password"]), data["full_name"], data["role"],
         data["dept_id"], data["year"], data["email"], data["nid_hash"], data["nid_last4"]),
    )


def validate_user_form(form):
    username = form.get("username", "").strip()
    full_name = form.get("full_name", "").strip()
    email = form.get("email", "").strip().lower()
    nid = form.get("national_id", "").strip()
    password = form.get("password", "")
    role = form.get("role", "")
    if not (username and full_name and email and nid and role in ROLES):
        return None, "required"
    if not EMAIL_RE.match(email):
        return None, "email_invalid"
    if check_national_id(nid):
        return None, "nid_invalid"
    if len(password) < MIN_PASSWORD_LENGTH:
        return None, "short_password"
    if len(password) > 256:
        return None, "long_password"
    if db().execute("SELECT 1 FROM users WHERE username = ?", (username,)).fetchone():
        return None, "username_taken"
    if db().execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
        return None, "email_taken"
    nid_hash = national_id_hash(nid)
    if db().execute("SELECT 1 FROM users WHERE national_id_hash = ?", (nid_hash,)).fetchone():
        return None, "nid_taken"
    dept_id = year = None
    if role == "student":
        dept = form.get("dept_id", "")
        yr = form.get("year", "")
        if not (dept.isdigit() and yr.isdigit() and int(yr) in YEARS):
            return None, "required"
        dept_id, year = int(dept), int(yr)
        if not db().execute("SELECT 1 FROM departments WHERE id = ?", (dept_id,)).fetchone():
            return None, "required"
    return {"username": username, "full_name": full_name, "email": email, "password": password,
            "role": role, "dept_id": dept_id, "year": year,
            "nid_hash": nid_hash, "nid_last4": nid[-4:]}, None


# ---------- Auth ----------

def login_throttle_key(username):
    raw = f"{request.remote_addr or 'unknown'}:{username.strip().lower()}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def login_is_blocked(key, now=None):
    now = now or _now()
    row = db().execute("SELECT blocked_until FROM login_throttles WHERE throttle_key = ?", (key,)).fetchone()
    return bool(row and row["blocked_until"] > now)


def record_login_failure(key, now=None):
    now = now or _now()
    conn = db()
    conn.execute("BEGIN IMMEDIATE")
    try:
        # Keep this small table bounded under repeated attacks using random usernames.
        conn.execute(
            "DELETE FROM login_throttles WHERE window_started < ? AND blocked_until < ?",
            (now - 24 * 60 * 60, now),
        )
        row = conn.execute(
            "SELECT window_started, failures FROM login_throttles WHERE throttle_key = ?", (key,)
        ).fetchone()
        if row is None or now - row["window_started"] > LOGIN_WINDOW_SECONDS:
            window_started, failures = now, 1
        else:
            window_started, failures = row["window_started"], row["failures"] + 1
        blocked_until = now + LOGIN_LOCK_SECONDS if failures >= LOGIN_MAX_FAILURES else 0
        conn.execute(
            "INSERT INTO login_throttles (throttle_key, window_started, failures, blocked_until) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(throttle_key) DO UPDATE SET window_started=excluded.window_started, "
            "failures=excluded.failures, blocked_until=excluded.blocked_until",
            (key, window_started, failures, blocked_until),
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def clear_login_failures(key):
    execute("DELETE FROM login_throttles WHERE throttle_key = ?", (key,))


@app.get("/")
def index():
    return redirect(url_for("departments") if current_user() else url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user():
        return redirect(url_for("departments"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        throttle_key = login_throttle_key(username)
        if login_is_blocked(throttle_key):
            flash(tt("invalid_login"), "error")
            return render_template("login.html"), 429
        password = request.form.get("password", "")
        if len(password) > 256:
            record_login_failure(throttle_key)
            flash(tt("invalid_login"), "error")
            return render_template("login.html")
        user = db().execute(
            "SELECT id, username, password_hash, full_name, email, email_verified "
            "FROM users WHERE username = ?", (username,)
        ).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            if not user["email_verified"]:
                sent = bool(user["email"]) and send_verification(user["id"], user["email"], user["full_name"])
                flash(tt("verify_needed") if sent else tt("mail_failed"), "error")
                return render_template("login.html")
            clear_login_failures(throttle_key)
            session.clear()
            session.permanent = True
            session["uid"] = user["id"]
            return redirect(safe_next(request.args.get("next")))
        record_login_failure(throttle_key)
        flash(tt("invalid_login"), "error")
    return render_template("login.html")


@app.route("/verify/<token>", methods=["GET", "POST"])
def verify_email(token):
    token_digest = hash_token(token)
    row = db().execute(
        "SELECT user_id, expires_at FROM email_tokens WHERE token_hash = ?", (token_digest,)
    ).fetchone()
    if row is None or row["expires_at"] < _now():
        flash(tt("verify_invalid"), "error")
        return redirect(url_for("login"))
    if request.method == "GET":
        # Do not consume verification links on GET: mail security scanners often pre-open links.
        return render_template("verify_email.html", token=token)
    conn = db()
    conn.execute("UPDATE users SET email_verified = 1 WHERE id = ?", (row["user_id"],))
    conn.execute("DELETE FROM email_tokens WHERE token_hash = ?", (token_digest,))
    conn.commit()
    flash(tt("verify_done"), "ok")
    return redirect(url_for("login"))


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.get("/lang/<code>")
def set_lang(code):
    if code in ("ar", "en"):
        session["lang"] = code
    return redirect(url_for("index"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user():
        return redirect(url_for("departments"))
    if request.method == "POST":
        form = request.form.to_dict()
        form["role"] = "student"  # self-registration can only create student accounts
        if form.get("password") != form.get("confirm_password"):
            flash(tt("password_mismatch"), "error")
        else:
            data, error = validate_user_form(form)
            if error:
                flash(tt(error), "error")
            else:
                try:
                    cur = insert_user(data)
                except sqlite3.IntegrityError:
                    flash(tt("required"), "error")
                else:
                    sent = send_verification(cur.lastrowid, data["email"], data["full_name"])
                    flash(tt("verify_sent") if sent else tt("mail_failed"), "ok" if sent else "error")
                    return redirect(url_for("login"))
    depts = db().execute("SELECT * FROM departments ORDER BY id").fetchall()
    return render_template("register.html", depts=depts, years=YEARS)


# ---------- Structure browsing ----------

@app.get("/departments")
@login_required
def departments():
    user = current_user()
    if user["role"] == "student":
        depts = db().execute("SELECT * FROM departments WHERE id = ? ORDER BY id", (user["dept_id"],)).fetchall()
    else:
        depts = db().execute("SELECT * FROM departments ORDER BY id").fetchall()
    return render_template("departments.html", depts=depts)


@app.get("/departments/<int:dept_id>")
@login_required
def department(dept_id):
    dept = get_department(dept_id)
    user = current_user()
    if user["role"] == "student":
        if user["dept_id"] != dept_id:
            abort(403)
        available_years = (user["year"],)
    else:
        available_years = YEARS
    return render_template("department.html", dept=dept, years=available_years)


@app.get("/departments/<int:dept_id>/years/<int:year>")
@login_required
def year_page(dept_id, year):
    dept = get_department(dept_id)
    if year not in YEARS:
        abort(404)
    user = current_user()
    if user["role"] == "student" and (user["dept_id"] != dept_id or user["year"] != year):
        abort(403)
    courses = db().execute(COURSE_SQL + " WHERE c.dept_id = ? AND c.year = ? ORDER BY c.term, c.position",
                           (dept_id, year)).fetchall()
    terms = {t: [c for c in courses if c["term"] == t] for t in TERMS}
    return render_template("year.html", dept=dept, year=year, terms=terms)


# ---------- Courses ----------

def valid_external_url(value):
    try:
        if any(char.isspace() or char == "\\" for char in value):
            return False
        parsed = urlsplit(value)
        _ = parsed.port  # force validation of malformed ports
        return (parsed.scheme in {"http", "https"} and bool(parsed.hostname)
                and parsed.username is None and parsed.password is None)
    except ValueError:
        return False


def valid_upload_signature(upload, extension):
    """Basic magic-byte verification. This is a safeguard, not malware scanning."""
    try:
        position = upload.stream.tell()
        header = upload.stream.read(16)
        upload.stream.seek(position)
    except (AttributeError, OSError):
        return False
    if extension == "pdf":
        return header.startswith(b"%PDF-")
    if extension in {"mp4", "mov"}:
        return len(header) >= 8 and header[4:8] == b"ftyp"
    if extension == "webm":
        return header.startswith(b"\x1a\x45\xdf\xa3")
    return False


@app.get("/course/<int:cid>")
@login_required
def course_page(cid):
    c = get_course(cid)
    if not can_view(c):
        abort(403)
    materials = db().execute("SELECT * FROM materials WHERE course_id = ? ORDER BY id DESC", (cid,)).fetchall()
    exams = db().execute(
        "SELECT e.*, (SELECT COUNT(*) FROM attempts a WHERE a.exam_id = e.id) AS taken "
        "FROM exams e WHERE e.course_id = ? ORDER BY e.id DESC", (cid,)
    ).fetchall()
    return render_template("course.html", c=c, materials=materials, exams=exams, manage=can_manage(c),
                           now=_now(), exam_status=exam_status)


@app.route("/course/<int:cid>/edit", methods=["GET", "POST"])
@role_required("admin")
def edit_course(cid):
    c = get_course(cid)
    if request.method == "POST":
        name_ar = request.form.get("name_ar", "").strip()
        name_en = request.form.get("name_en", "").strip()
        code = request.form.get("code", "").strip()
        doctor = request.form.get("doctor_id", "").strip()
        doctor_id = int(doctor) if doctor.isdigit() else None
        if not (name_ar and name_en and code):
            flash(tt("required"), "error")
        elif doctor_id is not None and not db().execute(
                "SELECT 1 FROM users WHERE id = ? AND role = 'doctor'", (doctor_id,)).fetchone():
            flash(tt("required"), "error")
        else:
            execute("UPDATE courses SET name_ar = ?, name_en = ?, code = ?, doctor_id = ? WHERE id = ?",
                    (name_ar, name_en, code, doctor_id, cid))
            flash(tt("saved"), "ok")
            return redirect(url_for("course_page", cid=cid))
    doctors = db().execute("SELECT id, full_name FROM users WHERE role = 'doctor' ORDER BY full_name").fetchall()
    return render_template("course_edit.html", c=c, doctors=doctors)


@app.post("/course/<int:cid>/materials")
@login_required
def add_material(cid):
    c = get_course(cid)
    if not can_manage(c):
        abort(403)
    back = url_for("course_page", cid=cid)
    title = request.form.get("title", "").strip()
    link = request.form.get("link", "").strip()
    upload = request.files.get("file")
    if not title:
        flash(tt("required"), "error")
        return redirect(back)
    if upload and upload.filename:
        ext = Path(upload.filename).suffix.lower().lstrip(".")
        if ext not in ALLOWED_EXT or not valid_upload_signature(upload, ext):
            flash(tt("bad_file"), "error")
            return redirect(back)
        stored = f"{uuid.uuid4().hex}.{ext}"
        target = UPLOAD_DIR / stored
        try:
            upload.save(target)
            execute("INSERT INTO materials (course_id, title, kind, stored_name) VALUES (?, ?, ?, ?)",
                    (cid, title, ALLOWED_EXT[ext], stored))
        except (OSError, sqlite3.Error):
            target.unlink(missing_ok=True)
            app.logger.exception("Could not store an uploaded course material")
            flash(tt("error"), "error")
            return redirect(back)
    elif link:
        if not valid_external_url(link):
            flash(tt("bad_url"), "error")
            return redirect(back)
        execute("INSERT INTO materials (course_id, title, kind, url) VALUES (?, ?, 'link', ?)",
                (cid, title, link))
    else:
        flash(tt("required"), "error")
        return redirect(back)
    flash(tt("saved"), "ok")
    return redirect(back)


@app.get("/material/<int:mid>")
@login_required
def material_file(mid):
    m = get_material(mid)
    if not can_view(m):
        abort(403)
    if m["kind"] == "link":
        return redirect(m["url"])
    return send_from_directory(UPLOAD_DIR, m["stored_name"], conditional=True)


@app.post("/material/<int:mid>/delete")
@login_required
def delete_material(mid):
    m = get_material(mid)
    if not can_manage(m):
        abort(403)
    if m["stored_name"]:
        (UPLOAD_DIR / m["stored_name"]).unlink(missing_ok=True)
    execute("DELETE FROM materials WHERE id = ?", (mid,))
    flash(tt("deleted"), "ok")
    return redirect(url_for("course_page", cid=m["course_id"]))


# ---------- Exams ----------

@app.post("/course/<int:cid>/exams")
@login_required
def create_exam(cid):
    c = get_course(cid)
    if not can_manage(c):
        abort(403)
    back = url_for("course_page", cid=cid)
    title = request.form.get("title", "").strip()
    duration = request.form.get("duration", "")
    if not title:
        flash(tt("required"), "error")
        return redirect(back)
    if not duration.isdigit() or not 1 <= int(duration) <= MAX_EXAM_MINUTES:
        flash(tt("invalid_duration"), "error")
        return redirect(back)
    ok_open, opens = parse_local_datetime(request.form.get("opens_at", ""))
    ok_close, closes = parse_local_datetime(request.form.get("closes_at", ""))
    if not (ok_open and ok_close) or (opens and closes and closes <= opens):
        flash(tt("invalid_window"), "error")
        return redirect(back)
    cur = execute("INSERT INTO exams (course_id, title, duration_minutes, opens_at, closes_at) "
                  "VALUES (?, ?, ?, ?, ?)", (cid, title, int(duration), opens, closes))
    return redirect(url_for("exam_page", eid=cur.lastrowid))


@app.get("/exam/<int:eid>")
@login_required
def exam_page(eid):
    e = get_exam(eid)
    if not can_view(e):
        abort(403)
    manage = can_manage(e)
    now = _now()
    status = exam_status(e, now)
    user = current_user()
    if manage:
        questions = db().execute("SELECT * FROM questions WHERE exam_id = ? ORDER BY id", (eid,)).fetchall()
    else:
        # Never put correct-answer fields in a student-facing template context.
        questions = db().execute(
            "SELECT id, text, opt1, opt2, opt3, opt4 FROM questions WHERE exam_id = ? ORDER BY id", (eid,)
        ).fetchall()
    attempt = started = None
    if user["role"] == "student":
        attempt = db().execute("SELECT * FROM attempts WHERE exam_id = ? AND student_id = ?",
                               (eid, user["id"])).fetchone()
        started = db().execute("SELECT started_at FROM exam_starts WHERE exam_id = ? AND student_id = ?",
                               (eid, user["id"])).fetchone()
    can_take = user["role"] == "student" and attempt is None and status == "open"
    if can_take and started is not None:
        deadline = started["started_at"] + e["duration_minutes"] * 60
        if e["closes_at"]:
            deadline = min(deadline, e["closes_at"])
        can_take = _now() <= deadline + EXAM_GRACE_SECONDS
    return render_template("exam.html", e=e, questions=questions, manage=manage, attempt=attempt,
                           status=status, can_take=can_take, started=started)


@app.post("/exam/<int:eid>/questions")
@login_required
def add_question(eid):
    e = get_exam(eid)
    if not can_manage(e):
        abort(403)
    if db().execute("SELECT 1 FROM exam_starts WHERE exam_id = ? LIMIT 1", (eid,)).fetchone():
        flash(tt("exam_locked"), "error")
        return redirect(url_for("exam_page", eid=eid))
    text = request.form.get("text", "").strip()
    opts = [request.form.get(f"opt{i}", "").strip() for i in range(1, 5)]
    correct = request.form.get("correct", "")
    if not text or not all(opts) or correct not in ("1", "2", "3", "4"):
        flash(tt("required"), "error")
    else:
        execute("INSERT INTO questions (exam_id, text, opt1, opt2, opt3, opt4, correct) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)", (eid, text, *opts, int(correct)))
        flash(tt("saved"), "ok")
    return redirect(url_for("exam_page", eid=eid))


@app.post("/question/<int:qid>/delete")
@login_required
def delete_question(qid):
    q = db().execute(
        "SELECT q.*, c.dept_id, c.year, c.doctor_id FROM questions q "
        "JOIN exams e ON e.id = q.exam_id JOIN courses c ON c.id = e.course_id WHERE q.id = ?", (qid,)
    ).fetchone()
    if q is None:
        abort(404)
    if not can_manage(q):
        abort(403)
    if db().execute("SELECT 1 FROM exam_starts WHERE exam_id = ? LIMIT 1", (q["exam_id"],)).fetchone():
        flash(tt("exam_locked"), "error")
        return redirect(url_for("exam_page", eid=q["exam_id"]))
    execute("DELETE FROM questions WHERE id = ?", (qid,))
    flash(tt("deleted"), "ok")
    return redirect(url_for("exam_page", eid=q["exam_id"]))


def save_attempt(eid, student_id, score, total):
    try:
        execute("INSERT INTO attempts (exam_id, student_id, score, total) VALUES (?, ?, ?, ?)",
                (eid, student_id, score, total))
        return True
    except sqlite3.IntegrityError:  # already submitted (e.g. double click)
        return False


@app.route("/exam/<int:eid>/take", methods=["GET", "POST"])
@login_required
def take_exam(eid):
    e = get_exam(eid)
    user = current_user()
    if user["role"] != "student" or not can_view(e):
        abort(403)
    if db().execute("SELECT 1 FROM attempts WHERE exam_id = ? AND student_id = ?",
                    (eid, user["id"])).fetchone():
        flash(tt("already_taken"), "error")
        return redirect(url_for("exam_page", eid=eid))

    # Keep grading keys server-side; only the safe projection is rendered in HTML.
    grading_questions = db().execute(
        "SELECT id, correct FROM questions WHERE exam_id = ? ORDER BY id", (eid,)
    ).fetchall()
    questions = db().execute(
        "SELECT id, text, opt1, opt2, opt3, opt4 FROM questions WHERE exam_id = ? ORDER BY id", (eid,)
    ).fetchall()
    if not questions:
        flash(tt("no_questions"), "error")
        return redirect(url_for("exam_page", eid=eid))

    now = _now()
    if request.method == "GET":
        existing_start = db().execute(
            "SELECT 1 FROM exam_starts WHERE exam_id = ? AND student_id = ?", (eid, user["id"])
        ).fetchone()
        if existing_start is None:
            status = exam_status(e, now)
            if status != "open":
                flash(tt("window_upcoming") if status == "upcoming" else tt("window_closed"), "error")
                return redirect(url_for("exam_page", eid=eid))
        # INSERT OR IGNORE makes concurrent first-page requests share one start timestamp.
        db().execute(
            "INSERT OR IGNORE INTO exam_starts (exam_id, student_id, started_at) VALUES (?, ?, ?)",
            (eid, user["id"], now),
        )
        db().commit()
    start = db().execute(
        "SELECT started_at FROM exam_starts WHERE exam_id = ? AND student_id = ?",
        (eid, user["id"]),
    ).fetchone()
    if start is None:
        flash(tt("start_first"), "error")
        return redirect(url_for("exam_page", eid=eid))

    start_time = start["started_at"]
    # The attempt ends at the duration limit, or at the closing time if that comes first.
    deadline = start_time + e["duration_minutes"] * 60
    if e["closes_at"]:
        deadline = min(deadline, e["closes_at"])
    expired = now >= deadline + EXAM_GRACE_SECONDS

    if request.method == "POST":
        score = 0
        if expired:
            flash(tt("time_up"), "error")
        else:
            correct_by_id = {q["id"]: q["correct"] for q in grading_questions}
            for question_id, correct in correct_by_id.items():
                answer = request.form.get(f"q{question_id}", "")
                if answer.isdigit() and int(answer) == correct:
                    score += 1
            flash(f"{tt('score')}: {score} {tt('of')} {len(grading_questions)}", "ok")
        if not save_attempt(eid, user["id"], score, len(grading_questions)):
            flash(tt("already_taken"), "error")
        return redirect(url_for("exam_page", eid=eid))

    if expired:
        flash(tt("time_up"), "error")
        save_attempt(eid, user["id"], 0, len(grading_questions))
        return redirect(url_for("exam_page", eid=eid))

    remaining = max(0, int(deadline - now))
    return render_template("take_exam.html", e=e, questions=questions, remaining=remaining)


# ---------- Admin ----------

@app.route("/admin/users", methods=["GET", "POST"])
@role_required("admin")
def admin_users():
    if request.method == "POST":
        data, error = validate_user_form(request.form)
        if error:
            flash(tt(error), "error")
        else:
            try:
                cur = insert_user(data)
            except sqlite3.IntegrityError:
                flash(tt("required"), "error")
            else:
                sent = send_verification(cur.lastrowid, data["email"], data["full_name"])
                flash(tt("created") if sent else tt("mail_failed"), "ok" if sent else "error")
        return redirect(url_for("admin_users"))
    users = db().execute(
        "SELECT u.id, u.username, u.full_name, u.role, u.dept_id, u.year, u.email, "
        "u.email_verified, u.national_id_last4, d.name_ar AS dept_name_ar, d.name_en AS dept_name_en "
        "FROM users u LEFT JOIN departments d ON d.id = u.dept_id ORDER BY u.role, u.full_name"
    ).fetchall()
    depts = db().execute("SELECT * FROM departments ORDER BY id").fetchall()
    return render_template("admin_users.html", users=users, depts=depts, roles=ROLES, years=YEARS)


@app.post("/admin/users/<int:uid>/delete")
@role_required("admin")
def delete_user(uid):
    if uid == current_user()["id"]:
        flash(tt("cannot_delete_self"), "error")
    else:
        execute("DELETE FROM users WHERE id = ?", (uid,))
        flash(tt("deleted"), "ok")
    return redirect(url_for("admin_users"))


# ---------- Health and errors ----------

@app.get("/healthz")
def healthz():
    try:
        db().execute("SELECT 1 FROM users LIMIT 1").fetchone()
    except sqlite3.Error:
        app.logger.exception("Health check failed because the database is unavailable")
        return {"status": "unavailable"}, 503
    return {"status": "ok"}, 200


@app.errorhandler(403)
def forbidden(_e):
    return render_template("error.html", message=tt("forbidden")), 403


@app.errorhandler(404)
def not_found(_e):
    return render_template("error.html", message=tt("not_found")), 404


@app.errorhandler(413)
def request_too_large(_e):
    return render_template("error.html", message=tt("bad_file")), 413


if __name__ == "__main__":
    # Development only. Production must use Gunicorn or another WSGI server.
    app.run(host="127.0.0.1", debug=False, port=int(os.environ.get("PORT", "5000")))
