"""WSGI entry point for Gunicorn and compatible production servers."""
from app import app

__all__ = ["app"]
