import re
from io import BytesIO
from types import SimpleNamespace

import pytest

import app as project


@pytest.fixture()
def seeded_app(tmp_path, monkeypatch):
    monkeypatch.setattr(project, "DB_PATH", tmp_path / "instance" / "test.db")
    monkeypatch.setattr(project, "UPLOAD_DIR", tmp_path / "uploads")
    project.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    project.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("ADMIN_PASSWORD", "Local-Test-Admin-Password-2026")
    project.app.config.update(TESTING=True, SECRET_KEY="test-secret-key-stable", PUBLIC_BASE_URL="")
    project.init_db()

    conn = project.connect()
    dept_id = conn.execute("SELECT id FROM departments ORDER BY id LIMIT 1").fetchone()[0]
    conn.execute(
        "INSERT INTO users (username,password_hash,full_name,role,dept_id,year,email,email_verified) "
        "VALUES (?,?,?,?,?,?,?,1)",
        ("student1", project.generate_password_hash("Student-Test-Password-2026"),
         "Test Student", "student", dept_id, 1, "student@example.test"),
    )
    student_id = conn.execute("SELECT id FROM users WHERE username='student1'").fetchone()[0]
    course_id = conn.execute(
        "SELECT id FROM courses WHERE dept_id=? AND year=1 ORDER BY id LIMIT 1", (dept_id,)
    ).fetchone()[0]
    exam_id = conn.execute(
        "INSERT INTO exams (course_id,title,duration_minutes) VALUES (?,?,?)",
        (course_id, "Test Exam", 30),
    ).lastrowid
    question_id = conn.execute(
        "INSERT INTO questions (exam_id,text,opt1,opt2,opt3,opt4,correct) VALUES (?,?,?,?,?,?,?)",
        (exam_id, "Two plus two?", "3", "4", "5", "6", 2),
    ).lastrowid
    conn.commit()
    conn.close()

    project.app.config["_TEST_IDS"] = {
        "dept_id": dept_id, "student_id": student_id,
        "course_id": course_id, "exam_id": exam_id, "question_id": question_id,
    }
    yield project.app.test_client()



def login_as(client, user_id):
    with client.session_transaction() as sess:
        sess["uid"] = user_id
        sess["csrf"] = "test-csrf-token"


def test_database_seed_is_idempotent(seeded_app):
    project.init_db()
    conn = project.connect()
    assert conn.execute("SELECT COUNT(*) FROM departments").fetchone()[0] == 3
    assert conn.execute("SELECT COUNT(*) FROM courses").fetchone()[0] == 168
    conn.close()


def test_post_without_csrf_is_rejected(seeded_app):
    response = seeded_app.post("/login", data={"username": "someone", "password": "bad"})
    assert response.status_code == 400


def test_student_cannot_open_another_department(seeded_app):
    ids = project.app.config["_TEST_IDS"]
    conn = project.connect()
    other_dept = conn.execute(
        "SELECT id FROM departments WHERE id != ? LIMIT 1", (ids["dept_id"],)
    ).fetchone()[0]
    conn.close()
    login_as(seeded_app, ids["student_id"])
    response = seeded_app.get(f"/departments/{other_dept}")
    assert response.status_code == 403


def test_student_only_sees_assigned_year(seeded_app):
    ids = project.app.config["_TEST_IDS"]
    login_as(seeded_app, ids["student_id"])
    response = seeded_app.get(f"/departments/{ids['dept_id']}/years/2")
    assert response.status_code == 403


def test_student_exam_pages_do_not_render_correct_answer_field(seeded_app):
    ids = project.app.config["_TEST_IDS"]
    login_as(seeded_app, ids["student_id"])
    response = seeded_app.get(f"/exam/{ids['exam_id']}")
    assert response.status_code == 200
    assert b"Two plus two?" not in response.data  # questions are shown only on the take page

    take_response = seeded_app.get(f"/exam/{ids['exam_id']}/take")
    assert take_response.status_code == 200
    assert b"Two plus two?" in take_response.data
    assert b"correct" not in take_response.data.lower()


def test_student_cannot_start_before_exam_opens(seeded_app):
    ids = project.app.config["_TEST_IDS"]
    conn = project.connect()
    conn.execute("UPDATE exams SET opens_at = ? WHERE id = ?", (project._now() + 3600, ids["exam_id"]))
    conn.commit()
    conn.close()
    login_as(seeded_app, ids["student_id"])
    response = seeded_app.get(f"/exam/{ids['exam_id']}/take")
    assert response.status_code == 302
    conn = project.connect()
    count = conn.execute(
        "SELECT COUNT(*) FROM exam_starts WHERE exam_id=? AND student_id=?",
        (ids["exam_id"], ids["student_id"]),
    ).fetchone()[0]
    conn.close()
    assert count == 0


def test_email_verification_get_does_not_activate_account(seeded_app):
    conn = project.connect()
    token = "one-time-verification-token"
    user_id = conn.execute(
        "INSERT INTO users (username,password_hash,full_name,role,email,email_verified) VALUES (?,?,?,?,?,0)",
        ("unverified", project.generate_password_hash("Another-Strong-Test-Password"),
         "Unverified", "student", "unverified@example.test"),
    ).lastrowid
    conn.execute(
        "INSERT INTO email_tokens (token_hash,user_id,expires_at) VALUES (?,?,?)",
        (project.hash_token(token), user_id, project._now() + 3600),
    )
    conn.commit()
    conn.close()

    response = seeded_app.get(f"/verify/{token}")
    assert response.status_code == 200
    conn = project.connect()
    verified = conn.execute("SELECT email_verified FROM users WHERE id=?", (user_id,)).fetchone()[0]
    conn.close()
    assert verified == 0


def test_upload_signature_checks_file_content():
    pdf = SimpleNamespace(stream=BytesIO(b"%PDF-1.7 sample"))
    fake_pdf = SimpleNamespace(stream=BytesIO(b"not a pdf at all"))
    webm = SimpleNamespace(stream=BytesIO(b"\x1a\x45\xdf\xa3webm-data"))
    assert project.valid_upload_signature(pdf, "pdf")
    assert not project.valid_upload_signature(fake_pdf, "pdf")
    assert project.valid_upload_signature(webm, "webm")


def test_external_url_requires_http_scheme_and_host():
    assert project.valid_external_url("https://example.com/video")
    assert not project.valid_external_url("javascript:alert(1)")
    assert not project.valid_external_url("https:///missing-host")
    assert not project.valid_external_url("https://user:pass@example.com")
